let programs=[];
async function loadPrograms(){
  programs = await fetch('data/funding_programs.json').then(r=>r.json());
  runMatch();
}
function val(id){return document.getElementById(id).value.trim();}
function scoreProgram(p, profile){
  let score=0, gaps=[];
  const text=(profile.project+' '+profile.stage+' '+profile.entity+' '+profile.region+' '+profile.openSource+' '+profile.need+' '+profile.aiCore).toLowerCase();
  const hay=(p.best_for.join(' ')+' '+p.region+' '+p.entity+' '+p.stage+' '+p.type).toLowerCase();
  p.best_for.forEach(k=>{ if(text.includes(k.toLowerCase())) score+=12; });
  if(profile.openSource==='Yes' && hay.includes('open')) score+=20;
  if(profile.entity==='Startup/SME' && (hay.includes('startup')||hay.includes('sme')||hay.includes('company'))) score+=18;
  if(profile.entity==='Individual/team' && (hay.includes('individual')||hay.includes('open-source'))) score+=14;
  if(profile.region && hay.includes(profile.region.toLowerCase())) score+=18;
  if(profile.stage && hay.includes(profile.stage.toLowerCase())) score+=10;
  if(profile.risk!=='None') {score-=8; gaps.push('Sensitive domain: add responsible AI and human review plan.');}
  if(profile.openSource==='No' && hay.includes('open')) gaps.push('Open-source evidence may be required.');
  if(p.name.includes('NSF') && !profile.region.includes('US')) gaps.push('Likely requires a US small business.');
  if(p.name.includes('EIC') && !profile.region.includes('EU')) gaps.push('EU/associated-country SME eligibility likely required.');
  if(p.name.includes('Innovate') && !profile.region.includes('UK')) gaps.push('UK entity or competition-specific route likely required.');
  score=Math.max(0,Math.min(100,score+25));
  return {program:p,score,gaps};
}
function runMatch(){
  const profile={project:val('project'),region:val('region'),entity:val('entity'),stage:val('stage'),openSource:val('openSource'),need:val('need'),aiCore:val('aiCore'),risk:val('risk')};
  const matches=programs.map(p=>scoreProgram(p,profile)).sort((a,b)=>b.score-a.score);
  const box=document.getElementById('matches'); box.innerHTML='';
  matches.slice(0,6).forEach(m=>{
    const div=document.createElement('div'); div.className='match';
    const cls=m.score>=70?'ok':m.score>=45?'warn':'bad';
    div.innerHTML=`<div class="score ${cls}">${m.score}</div><b>${m.program.name}</b><div class="small">${m.program.funder} · ${m.program.type} · ${m.program.amount}</div><p>${m.program.hard_rules.join(' · ')}</p>${m.gaps.length?'<p class="bad">Gaps: '+m.gaps.join(' | ')+'</p>':'<p class="ok">No obvious hard gap in prototype rules.</p>'}<a href="${m.program.url}" target="_blank">Official source</a>`;
    box.appendChild(div);
  });
  generatePack(matches[0],profile);
}
function generatePack(best, profile){
  const evidenceRows=[
    ['D','Project facts','Add GitHub/demo/team evidence'],
    ['I','Differentiation','Add competitor/user pain evidence'],
    ['K','Technical grounding','Add paper/benchmark/standard source'],
    ['W','Trade-off','Add risk, budget, milestone rationale'],
    ['P','Purpose','Align with funder mission and responsible AI']
  ];
  document.getElementById('dikwp').innerHTML='<tr><th>Layer</th><th>Claim area</th><th>Required repair</th></tr>'+evidenceRows.map(r=>`<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join('');
  const out=`Project title: ${profile.project || '[insert project title]'}\n\nRecommended first route: ${best?best.program.name:'[run match]'}\n\nDraft grant abstract:\nThis project develops ${profile.aiCore || '[AI method/system]'} for ${profile.need || '[target user/problem]'}, addressing a concrete gap in current AI innovation practice. Existing routes are insufficient because the project requires evidence-linked development, responsible AI controls, and a clear path from prototype to adoption. The requested support will fund a staged workplan: prototype validation, evidence collection, responsible AI review, user testing, and submission-ready reporting. The project will maintain a DIKWP evidence ledger covering data provenance, information distinction, knowledge grounding, wisdom-level trade-offs, and purpose alignment.\n\nImmediate repair actions:\n1. Add repository/demo evidence.\n2. Clarify legal eligibility and country/entity status.\n3. Attach budget-to-milestone map.\n4. Add responsible AI risk statement for ${profile.risk || 'risk category'}.\n5. Verify official program page before submission.`;
  document.getElementById('pack').textContent=out;
}
document.addEventListener('input', e=>{ if(e.target.matches('input,select,textarea')) runMatch(); });
window.addEventListener('load', loadPrograms);
