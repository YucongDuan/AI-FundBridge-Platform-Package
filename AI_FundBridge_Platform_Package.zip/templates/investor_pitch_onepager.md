# AI Startup Investor One-Pager

**Company/project:**

**One-liner:**

**Customer pain:**

**AI-native solution:**

**Technical moat:**

**Market and initial segment:**

**Traction/evidence:**

**Business model:**

**Responsible AI controls:**

**Funding ask:**

**Next 6-month milestones:**

**Team:**
