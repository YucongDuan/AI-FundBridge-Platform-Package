# AI FundBridge Grant Application Canvas

## 1. Project title

## 2. Applicant and legal entity

## 3. Funding route and official source URL

## 4. Problem and target users

## 5. AI solution and technical core

## 6. DIKWP evidence ledger
- D / Data: facts, code, demo, dataset, team evidence
- I / Information: differentiation, eligibility gaps, user pain
- K / Knowledge: technical, market and policy grounding
- W / Wisdom: risk trade-offs, budget choices, milestones
- P / Purpose: funder mission, public value, commercial impact

## 7. Work packages

## 8. Budget and milestones

## 9. Responsible AI and risk controls

## 10. Submission checklist
- [ ] Official eligibility verified
- [ ] Deadline verified
- [ ] Core claims supported by evidence
- [ ] Budget maps to milestones
- [ ] Human review completed
