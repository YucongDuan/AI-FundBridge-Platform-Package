# AI FundBridge Email Templates

## Eligibility confirmation email
Subject: Eligibility confirmation for [program] application

Dear [Program Officer],

We are preparing a potential application to [program] for [project]. Before preparing a full proposal, may we confirm whether the following applicant profile is eligible?

- Applicant/entity: [type]
- Country/region: [country]
- Project stage: [stage]
- Funding need: [amount/resource]
- AI domain: [domain]

A short non-confidential project summary is attached. We understand that final eligibility will depend on the official rules and submission portal.

Best regards,
[Name]

## Mentor review email
Subject: Request for review of AI funding application draft

Dear [Name],

We are preparing an AI innovation funding application for [project]. Could you review the attached one-page proposal and evidence ledger, focusing on eligibility, novelty, budget realism and responsible AI risks?

We are not asking for endorsement unless you are comfortable after review; critical feedback is preferred.

Best regards,
[Name]

## Investor outreach email
Subject: AI-native [category] project seeking [ask]

Dear [Name],

We are building [company/product], an AI-native solution for [customer segment] that addresses [pain]. We have [traction/evidence] and are seeking [funding/partner ask] to reach [milestone].

I attach a one-page summary and would welcome a brief fit discussion.

Best regards,
[Name]
