# Source Ledger

Checked: 2026-07-04.

- YucongDuan GitHub profile: https://github.com/YucongDuan
- DIKWP SemanticJustice Studio V2: https://github.com/YucongDuan/DIKWP-SemanticJustice-Studio-V2
- DIKWP Consciousness Futures Studio V1: https://github.com/YucongDuan/DIKWP-Consciousness-Futures-Studio-V1
- AI Grant open-source grants: https://aigrant.org/
- AI Grant accelerator: https://aigrant.com/
- GitHub Fund: https://github.com/open-source/github-fund
- GitHub Accelerator: https://github.com/open-source/accelerator
- EIC Accelerator: https://eic.ec.europa.eu/eic-funding-opportunities/eic-accelerator_en
- NSF SBIR/STTR AI topic: https://seedfund.nsf.gov/topics/artificial-intelligence/
- Innovate UK competitions: https://apply-for-innovation-funding.service.gov.uk/competition/search
- AI NATION Grant: https://www.ai-nation.de/grant
- Open Collective: https://opencollective.com/

Operational rule: funding program data changes frequently. The platform must store source URL, checked date, eligibility notes and next verification date for every program.
